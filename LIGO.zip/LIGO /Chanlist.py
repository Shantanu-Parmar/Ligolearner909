import csv
from gwpy.detector import ChannelList, Channel

# NDS2 server
server = 'losc-nds.ligo.org'

with open('chanlist.csv', mode='w', newline='') as file:
    writer = csv.writer(file)
    chanlist = ChannelList.query_nds2('*', host='losc-nds.ligo.org' )
    print("Found {0} channels\n".format(len(chanlist)))
    print("Printing first 10 channels ...")
    for chan in chanlist[0::]:
        print(chan.name, chan.sample_rate)
        writer.writerow([chan.name, chan.sample_rate])
